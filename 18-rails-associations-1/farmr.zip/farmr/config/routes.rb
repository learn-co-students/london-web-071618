Rails.application.routes.draw do
  resources :grazings
  resources :fields
  resources :cows
  resources :farmers
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
