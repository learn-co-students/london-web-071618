module GrazingsHelper
end
