module CowsHelper
end
