class CowsController < ApplicationController

  def index
    @cows = Cow.all
  end

  def show
    @cow = Cow.find_by_id(params[:id])
  end

  def new
    @cow = Cow.new()
  end

  def create
    @cow = Cow.create(cow_params)
    if @cow.valid?
      redirect_to @cow
    else
      flash[:errors] = @cow.errors.full_messages
      redirect_to new_cow_path
    end
  end

  private
  def cow_params
    params.require(:cow).permit(:name, :spots, :farmer_id)
  end
end
