class FarmersController < ApplicationController
end
