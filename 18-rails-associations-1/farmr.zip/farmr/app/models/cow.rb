class Cow < ApplicationRecord
  belongs_to :farmer

  has_many :grazings
  has_many :fields, through: :pairings

  validates :name, {presence: true, uniqueness: true}
  validates :spots, numericality: { less_than_or_equal_to: 50 }
end
