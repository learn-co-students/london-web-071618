class Farmer < ApplicationRecord
  has_many :cows
end
