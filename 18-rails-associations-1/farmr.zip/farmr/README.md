
# init the resources
`rails g model Field name`
`rails g model Grazing field:belongs_to cow:belongs_to`

build controllers and routes
rails db:migrate
add has many and hmt to cow and field models, as grazing will have it already
in the controller for new, set the collection that we will need for a pairing
permit param has to include a array permit, not a normal one
add the form checkbox
use show templates for field and cow to refer to the relationship (edited)
