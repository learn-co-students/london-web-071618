require 'test_helper'

class GrazingTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
