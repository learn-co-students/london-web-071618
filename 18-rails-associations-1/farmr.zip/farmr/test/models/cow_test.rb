require 'test_helper'

class CowTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
